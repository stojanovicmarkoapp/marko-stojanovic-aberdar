<?php

define("SERVER", "localhost");
define("DATABASE", 	"aberdar");
define("USERNAME", "root");
define("PASSWORD", "");