<?php
    require_once("common/controller-includes.php");

    require_once("../data/comment.php");
    $className = "Comment";

    require_once("common/crud.php");