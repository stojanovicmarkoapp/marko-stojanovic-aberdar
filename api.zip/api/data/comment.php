<?php

class Comment extends Base {
    static function getTableName() {
        return "comments";
    }

    // all props except id
    static function getProps() {
        return ["content", "storyId", "ipAddress","nickname","changed"];
    }
}