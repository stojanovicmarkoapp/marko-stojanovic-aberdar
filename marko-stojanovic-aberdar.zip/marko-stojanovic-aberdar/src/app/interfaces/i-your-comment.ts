export interface IYourComment {
    content:string,
    storyId: number,
    ipAddress: string,
    nickname: string
}
