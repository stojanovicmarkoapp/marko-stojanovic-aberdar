export interface INavigator {
    id: number;
    routerLink : string;
    icon: string;
    label: string;
}
