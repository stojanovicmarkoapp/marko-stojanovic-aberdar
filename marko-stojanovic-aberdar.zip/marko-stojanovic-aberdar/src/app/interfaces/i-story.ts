export interface IStory {
    id: number,
    title: string,
    type: string,
    category: string,
    content: string,
    image : {
        src: string,
        alt: string
    },
    published: string,
    author: string,
    tags: string[]
}
