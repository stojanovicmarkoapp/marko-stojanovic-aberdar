export interface IAdvertisement {
    id: number,
    name: string,
    advertiser: string,
    category: string,
    isActive : boolean,
    image : {
        src: string,
        alt : string
    }
}
