export interface IComment {
    id: number,
    content:string,
    storyId: number,
    ipAddress: string,
    nickname: string,
    changed: string
}
