import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { IAdvertisement } from '../interfaces/i-advertisement';

@Injectable({
  providedIn: 'root'
})
export class AdvertisementsService {

  constructor(private http:HttpClient) { }
  readonly url:string = "assets/data/advertisements.json";
  getAdvertisements(category:string):Observable<IAdvertisement[]>{
    if(category=="start"){
      return this.http.get<IAdvertisement[]>(this.url)
      .pipe(
        map((advertisements: IAdvertisement[])=>advertisements.filter(ad=>ad.isActive==true)
      ));
    }
    else {
      return this.http.get<IAdvertisement[]>(this.url)
      .pipe(
        map((advertisements: IAdvertisement[])=>advertisements.filter(ad=>ad.category==category && ad.isActive==true)
      ));
    }
  }
}
