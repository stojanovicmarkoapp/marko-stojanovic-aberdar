import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { INavigator } from '../interfaces/i-navigator';

@Injectable({
  providedIn: 'root'
})
export class NavigatorService {
  constructor( private http: HttpClient) { }
  readonly url: string = "assets/data/navigator.json";
  getNavigator(): Observable<INavigator[]> {
    return this.http.get<INavigator[]>(this.url);
  }
}

