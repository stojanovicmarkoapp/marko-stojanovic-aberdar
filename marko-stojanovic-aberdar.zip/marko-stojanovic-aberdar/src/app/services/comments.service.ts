import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { api } from 'src/app/constants/api';
import { server } from 'src/app/constants/server';
import { IComment } from '../interfaces/i-comment';
import { IYourComment } from '../interfaces/i-your-comment';

@Injectable({
  providedIn: 'root'
})
export class CommentsService {
  constructor(private http:HttpClient) { }
  getAllComments(): Observable<IComment[]>{
    return this.http.get<IComment[]>(server+api.comments);
  }
  getComment(id:any): Observable<IComment>{
    return this.http.get<IComment>(server + api.comments + "/" + id);
  }
  createComment(data:IYourComment):Observable<IComment>{
    return this.http.post<IComment>(server+api.comments,data);
  }
  updateComment(id:any,data:IYourComment):Observable<IComment>{
    return this.http.patch<IComment>(server+api.comments+"/"+id,data);
  }
  deleteComment(id:any):Observable<IComment>{
    return this.http.delete<IComment>(server+api.comments+"/"+id);
  }
}
