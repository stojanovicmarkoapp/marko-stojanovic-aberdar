import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { IStory } from '../interfaces/i-story';

@Injectable({
  providedIn: 'root'
})
export class StoriesService {
  constructor(private http: HttpClient) { }
  readonly url:string = "assets/data/stories.json";
  getStories(category:string): Observable<IStory[]>{
    if(category=="start"){
      return this.http.get<IStory[]>(this.url);
    }
    else {
      return this.http.get<IStory[]>(this.url)
      .pipe(
        map((stories: IStory[])=>stories.filter(story=>story.category==category)
      ));
    }
  }
  getStory(id:number): Observable<IStory>{
    return this.http.get<any>(this.url)
      .pipe(
        map((stories: IStory[])=>stories.find((story: {id:number;})=>story.id==id)
      ));
  }
}
