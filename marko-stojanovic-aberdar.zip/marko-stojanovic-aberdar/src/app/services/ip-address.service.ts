import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import axios from 'axios';

@Injectable({
  providedIn: 'root'
})
export class IpAddressService {
  constructor() { }
  getIpAddress(): Observable<string> {
    return new Observable<string>(observer=>{
      axios.get("https://api.ipify.org?format=json")
      .then(response=>{
        observer.next(response.data.ip);
        observer.complete();
      })
      .catch(error=>{
        observer.error(error);
      })
    });
  }
}
