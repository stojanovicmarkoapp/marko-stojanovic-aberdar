import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export function NicknameValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value: string = control.value;
    const pattern: RegExp = /^[a-zA-Z0-9\-]+$/;

    if (!pattern.test(value)) {
      return { invalidNickname: true };
    }

    return null;
  };
}