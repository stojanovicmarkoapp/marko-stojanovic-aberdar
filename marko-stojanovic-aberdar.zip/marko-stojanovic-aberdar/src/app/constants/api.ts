export const api = {
  comments : "comments.php"
}