import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IStory } from 'src/app/interfaces/i-story';
import { StoriesService } from 'src/app/services/stories.service';
@Component({
  selector: 'app-story',
  templateUrl: './story.component.html',
  styleUrls: ['./story.component.css']
})
export class StoryComponent implements OnInit {
  story: IStory;
  storyId: number;
  ipAddress:string;
  constructor(private storiesService:StoriesService,
    private router:Router) {
    this.storyId = parseInt(this.router.url.split("/")[2]);
    this.storiesService.getStory(this.storyId)
      .subscribe(data => {
        this.story=data;
      },
      error => {
        console.error(error);
      });
      }
  ngOnInit(): void {}
    
      // this.ipAddressService.getIpAddress()
      // .subscribe(ipAddress=>{
      //     this.ipAddress=ipAddress;
      //   },
      //   error => {
      //     console.error(error);
      // });
    // this.commentsService.getAllComments()
    //   .subscribe(data => {
    //     this.allComments=data;
    //   },
    //   error => {
    //     console.error(error);
    //   });
  // }
  // writeYourComment(){
  //   this.yourOldComment = this.allComments.find(comment=>comment.storyId==this.id && comment.ipAddress==this.ipAddress);
  // }
  // addingComment(){
  //   let yourComment:IYourComment = {
  //     content : this.yourComment.get("yourContent").value,
  //     storyId : this.id,
  //     ipAddress :  this.ipAddress
  //   }
  //   this.commentsService.createComment(yourComment).subscribe(
  //     (response)=>{
  //     },
  //     (error)=>{
  //       console.error(error);
  //     }
  //   );
  // }
  // changingComment(){
  //   let commentId = this.yourOldComment.id;
  //   let yourComment:IYourComment = {
  //     content : this.yourComment.get("yourContent").value,
  //     storyId : this.id,
  //     ipAddress :  this.ipAddress
  //   }
  //   this.commentsService.updateComment(commentId,yourComment);
  // }
  // savingComment(){
  //   let yourComment:IYourComment = {
  //         content : this.yourComment.get("yourContent").value,
  //         storyId : this.storyId,
  //         ipAddress :  this.ipAddress
  //       }
  //   if(!this.yourOldComment){
  //     this.commentsService.createComment(yourComment).subscribe(
  //           (response)=>{
  //             alert("Успешно сте додали коментар!");
  //           },
  //           (error)=>{
  //             console.error(error);
  //           }
  //         );
  //   }
  //   else {
  //     let commentId = this.yourOldComment.id;
  //     this.commentsService.updateComment(commentId,yourComment).subscribe(
  //       (response)=>{
  //         alert("Успешно сте изменили коментар!");
  //       },
  //       (error)=>{
  //         console.error(error);
  //       }
  //     );
  //   }
  // }
  // deletingComment(){
  //   let commentId = this.yourOldComment.id;
  //   this.commentsService.deleteComment(commentId).subscribe(
  //     (response)=>{
  //       alert("Успешно сте избрисали свој коментар!");
  //     },
  //     (error)=>{
  //       console.error(error);
  //     }
  //   );
  // }

}
