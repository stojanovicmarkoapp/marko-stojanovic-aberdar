import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-economic-propaganda',
  templateUrl: './economic-propaganda.component.html',
  styleUrls: ['./economic-propaganda.component.css']
})
export class EconomicPropagandaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
