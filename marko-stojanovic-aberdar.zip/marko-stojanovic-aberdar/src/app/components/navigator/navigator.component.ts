import { Component, HostListener, OnInit } from '@angular/core';
import { INavigator } from 'src/app/interfaces/i-navigator';
import { NavigatorService } from 'src/app/services/navigator.service';
@Component({
  selector: 'app-navigator',
  templateUrl: './navigator.component.html',
  styleUrls: ['./navigator.component.css']
})
export class NavigatorComponent implements OnInit {
  navigator: INavigator[] = [];
  isScreenSmall:boolean = false;
  isSidenavOpen:boolean = false;
  bellow801:boolean = false;
  constructor(private navigatorService:NavigatorService) {}
  ngOnInit(): void {
    this.checkScreenSize();
    this.navigatorService.getNavigator().subscribe({
      next:data=>{
        this.navigator=data
      },
      error: err=>{
        console.error(err);
      }
    });
  }
  @HostListener("window:resize",["$event"])
  onResize(event: any):void {
    this.checkScreenSize();
    this.bellow801 = window.innerWidth<801;
  }
  private checkScreenSize():void{
    this.isScreenSmall = window.innerWidth<600;
  }
  toggleSidenav(){
    this.isSidenavOpen = !this.isSidenavOpen;
  }
}