import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IStory } from 'src/app/interfaces/i-story';
import { StoriesService } from 'src/app/services/stories.service';
@Component({
  selector: 'app-stories',
  templateUrl: './stories.component.html',
  styleUrls: ['./stories.component.css']
})
export class StoriesComponent implements OnInit {
  stories: IStory[];
  reloadedStories: IStory[];
  keyword: string;
  checkedFeuilleton: boolean;
  checkedReport: boolean;
  fromDate:Date | null;
  untilDate:Date | null;
  //fromDate:string;
  //untilDate:string;
  category:string;
  constructor(private storiesService: StoriesService, private router:Router) {
    this.category= this.router.url.split("/")[1];
  }
  ngOnInit(): void {
    this.storiesService.getStories(this.category).subscribe(data => {
      this.stories = data;
      this.reloadedStories = [...this.stories];
    });
  }
  proceedToStory(id:number){
    this.router.navigate(["/stories",id]);
  }
  convertDateFormat(date:string):string {
    const parts = date.split("/");
    const day = parts[0];
    const month = parts[1];
    const year = parts[2];
    const paddedDay = day.padStart(2,"0");
    const paddedMonth = month.padStart(2,"0");
    return `${year}-${paddedMonth}-${paddedDay}`;
  }
  reloadStories(): void {
    const upperKeyword:string = this.keyword.trim().toUpperCase();
    const allUnchecked:boolean = !this.checkedFeuilleton && !this.checkedReport;
    this.reloadedStories = this.stories.filter(story=>{
      const upperTags:string[] = story.tags.map(tag=>tag.toUpperCase());
      const matchesKeyword:boolean = this.keyword.trim() == ""
        || story.title.toUpperCase().includes(upperKeyword)
        || upperTags.some(upperTag=>upperTag.includes(upperKeyword));
      const matchesCheckboxes:boolean = allUnchecked ||
        (this.checkedFeuilleton && story.type=="Фељтон") ||
        (this.checkedReport && story.type=="Репортажа");
      if(this.fromDate || this.untilDate){
        const published = this.convertDateFormat(story.published);
        const storyDate = new Date(published);
        if(this.fromDate && this.untilDate){
          return matchesKeyword && matchesCheckboxes && storyDate>=this.fromDate && storyDate<=this.untilDate;
        }
        else if(this.fromDate){
          return matchesKeyword && matchesCheckboxes && storyDate>=this.fromDate;
        }
        else if(this.untilDate){
          return matchesKeyword && matchesCheckboxes && storyDate<=this.untilDate;
        }
      }
      return matchesKeyword && matchesCheckboxes;
    });
  }
}