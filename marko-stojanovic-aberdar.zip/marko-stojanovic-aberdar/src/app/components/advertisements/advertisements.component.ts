import { Component, Input, OnInit } from '@angular/core';
//import { IAdvertisement } from 'src/app/interfaces/i-advertisement';
//import { AdvertisementsService } from 'src/app/services/advertisements.service';

@Component({
  selector: 'app-advertisements',
  templateUrl: './advertisements.component.html',
  styleUrls: ['./advertisements.component.css']
})
export class AdvertisementsComponent implements OnInit {
  //@Input() category: string;
  //@Input() side: string;
  currentAd: any;
  intervalId: any;
  //advertisements: IAdvertisement[];
  constructor() {}
  ngOnInit(): void {
    // this.advertisementsService.getAdvertisements(this.category).subscribe(data=>{
    //   this.advertisements = data;
    // });
    //this.startCarousel();
  }
  // ngOnDestroy():void {
  //   this.stopCarousel();
  // }
  // startCarousel():void {
  //   let index = 0;
  //   this.currentAd = this.advertisements[index];
  //   this.intervalId = setInterval(()=>{
  //     index = (index+1) % this.advertisements.length;
  //     this.currentAd = this.advertisements[index];
  //   },10000);
  // }
  // stopCarousel():void {
  //   clearInterval(this.intervalId);
  // }
}
