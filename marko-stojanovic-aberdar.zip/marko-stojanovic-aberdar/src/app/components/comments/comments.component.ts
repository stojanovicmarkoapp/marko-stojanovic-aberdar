import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { forkJoin, Observable } from 'rxjs';
import { IComment } from 'src/app/interfaces/i-comment';
import { IYourComment } from 'src/app/interfaces/i-your-comment';
import { CommentsService } from 'src/app/services/comments.service';
import { IpAddressService } from 'src/app/services/ip-address.service';
import { NicknameValidator } from 'src/app/validators/nickname.validator';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.css']
})
export class CommentsComponent implements OnInit {
  storyId: number;
  yourOldComment: IComment;
  storyComments: IComment[];
  ipAddress:string;
  nicknameRegex = /^[a-zA-Z0-9\-]+$/;
  yourComment = new FormGroup({
    yourContent: new FormControl("",[Validators.required]),
    nickname: new FormControl('', [Validators.required, NicknameValidator()])
  })
  constructor(private commentsService:CommentsService,
    private router:Router,
    private ipAddressService:IpAddressService,
    private cdr: ChangeDetectorRef){
    this.storyId = parseInt(this.router.url.split("/")[2]);
  }
  ngOnInit(): void {
    let commentServiceData: Observable<IComment[]> = this.commentsService.getAllComments();
      let ipAddressServiceData: Observable<string> = this.ipAddressService.getIpAddress();
      forkJoin([commentServiceData,ipAddressServiceData])
        .subscribe(([data1,data2])=>{
          this.ipAddress = data2;
          this.storyComments = data1.filter(comment=>comment.storyId==this.storyId && comment.ipAddress!=data2);
          console.log(this.storyComments);
          this.yourOldComment = data1.find(comment=>comment.storyId==this.storyId && comment.ipAddress==data2);
          this.cdr.detectChanges();
        },error => {
          console.error(error);
        });
  }
  savingComment(){
    let yourComment:IYourComment = {
      content : this.yourComment.get("yourContent").value,
      storyId : this.storyId,
      nickname: this.yourComment.get("nickname").value,
      ipAddress :  this.ipAddress
    }
    if(!this.yourOldComment){
      this.commentsService.createComment(yourComment).subscribe(
            (response)=>{
              alert("Успешно сте додали коментар!");
              window.location.reload();
            },
            (error)=>{
              console.error(error);
            }
          );
    }
    else {
      let commentId = this.yourOldComment.id;
      this.commentsService.updateComment(commentId,yourComment).subscribe(
        (response)=>{
          alert("Успешно сте изменили коментар!");
          window.location.reload();
        },
        (error)=>{
          console.error(error);
        }
      );
    }
  }
  deletingComment(){
    let commentId = this.yourOldComment.id;
    this.commentsService.deleteComment(commentId).subscribe(
      (response)=>{
        alert("Успешно сте избрисали свој коментар!");
        window.location.reload();
      },
      (error)=>{
        console.error(error);
      }
    );
  }

}
