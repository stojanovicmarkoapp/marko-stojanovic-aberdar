import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EconomicPropagandaComponent } from './components/economic-propaganda/economic-propaganda.component';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { OurStoryComponent } from './components/our-story/our-story.component';
import { PersonnelComponent } from './components/personnel/personnel.component';
import { StoriesComponent } from './components/stories/stories.component';
import { StoryComponent } from './components/story/story.component';

const routes: Routes = [
  {
    path: "",
    redirectTo: "/start",
    pathMatch: "full"
  },
  {
    path: "start",
    component: StoriesComponent
  },
  {
    path: "informative",
    component: StoriesComponent
  },
  {
    path: "sport",
    component: StoriesComponent
  },
  {
    path: "culture",
    component: StoriesComponent
  },
  {
    path: "economics",
    component: StoriesComponent
  },
  {
    path: "economic-propaganda",
    component: EconomicPropagandaComponent
  },
  {
    path: "personnel",
    component: PersonnelComponent
  },
  {
    path: "our-story",
    component: OurStoryComponent
  },
  {
    path: "stories/:id",
    component: StoryComponent
  },
  {
    path: "**",
    component: NotFoundComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
