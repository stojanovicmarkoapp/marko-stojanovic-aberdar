import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'customTimestamp'
})
export class CustomTimestampPipe implements PipeTransform {
  transform(timestamp: any): string {
    if (timestamp) {
      const date = new Date(timestamp);
      const day = this.addLeadingZero(date.getDate());
      const month = this.addLeadingZero(date.getMonth() + 1);
      const year = date.getFullYear();
      const hours = this.addLeadingZero(date.getHours());
      const minutes = this.addLeadingZero(date.getMinutes());
      const seconds = this.addLeadingZero(date.getSeconds());

      return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
    }
    return '';
  }

  private addLeadingZero(value: number): string {
    return value < 10 ? `0${value}` : `${value}`;
  }
}